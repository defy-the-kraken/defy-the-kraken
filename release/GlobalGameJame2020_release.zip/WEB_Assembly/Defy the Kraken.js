version https://git-lfs.github.com/spec/v1
oid sha256:00c97177021a299c54c2cd1e923242efe45851d4f726622ba9688dd2a6bb3240
size 337971
